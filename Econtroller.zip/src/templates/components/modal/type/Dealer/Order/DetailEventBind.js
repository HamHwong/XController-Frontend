$("#Detail")
  .on("hidden.bs.modal", function() {
      $("#progressbar").empty()
    }
)
