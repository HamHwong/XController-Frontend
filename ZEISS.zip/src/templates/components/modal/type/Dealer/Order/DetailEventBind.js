$("#Detail")
  .on("hidden.bs.modal", function() {
      PRDetail.destory()
    }
)
